<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_United States</name>
   <tag></tag>
   <elementGuidId>e749083d-3f58-4ac5-afb6-e4e77c8333f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[@id='icp-dropdown']/span/span/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-dropdown-prompt</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>fafa42c6-e76a-4f81-a196-722cbd7060ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-dropdown-prompt</value>
      <webElementGuid>b8f65f70-d7f0-4891-a223-136412bd6a50</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                    United States
                            </value>
      <webElementGuid>3e2767a7-7418-45b0-bf2f-2da44e1171fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-row a-spacing-extra-large a-spacing-top-base a-ws-row&quot;]/div[@class=&quot;a-column a-span12 a-ws-span10 a-ws-spacing-none&quot;]/div[@class=&quot;a-row a-ws-row&quot;]/div[@class=&quot;a-column a-span12 a-ws-span7&quot;]/span[@class=&quot;a-dropdown-container&quot;]/span[@id=&quot;icp-dropdown&quot;]/span[@class=&quot;a-button-inner&quot;]/span[@class=&quot;a-button-text a-declarative&quot;]/span[@class=&quot;a-dropdown-prompt&quot;]</value>
      <webElementGuid>32a71e4d-a93b-4499-bd95-2ef710cd8691</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//span[@id='icp-dropdown']/span/span/span</value>
      <webElementGuid>d9bb4340-3052-4d22-8861-aae2bcc888c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span/span/span/span</value>
      <webElementGuid>8ab16198-3bfb-4fee-a167-383fd1adbbef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                                    United States
                            ' or . = '
                                    United States
                            ')]</value>
      <webElementGuid>ac5a5a29-5d5c-4667-ab95-dbcb57c42d65</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
