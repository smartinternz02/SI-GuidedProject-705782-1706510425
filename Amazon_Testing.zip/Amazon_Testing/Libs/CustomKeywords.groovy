
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject



def static "customkeyword.helloworld.printHello"(
    	String name	) {
    (new customkeyword.helloworld()).printHello(
        	name)
}


def static "customkeyword.helloworld.CheckDropdownListElementExist"(
    	TestObject object	
     , 	String option	) {
    (new customkeyword.helloworld()).CheckDropdownListElementExist(
        	object
         , 	option)
}
